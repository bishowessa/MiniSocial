package controller;

import model.Post;
import model.Comment;
import service.PostService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/posts")
public class PostController {

    private PostService postService = new PostService();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void createPost(Post post) {
        postService.createPost(post);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Post> getFeed(@QueryParam("user") String user) {
        return postService.getUserFeed(user);
    }

    @POST
    @Path("/{postId}/comment")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addComment(@PathParam("postId") String postId, Comment comment) {
        postService.addComment(postId, comment);
    }

    @POST
    @Path("/{postId}/like")
    public void likePost(@PathParam("postId") String postId) {
        postService.likePost(postId);
    }
}