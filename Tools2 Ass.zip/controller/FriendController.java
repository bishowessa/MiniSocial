package controller;

import service.FriendService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/friends")
public class FriendController {

    private FriendService friendService = new FriendService();

    @POST
    @Path("/request")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public void sendRequest(@FormParam("from") String from, @FormParam("to") String to) {
        friendService.sendRequest(from, to);
    }

    @POST
    @Path("/respond")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public void respond(@FormParam("from") String from, @FormParam("to") String to, @FormParam("accept") boolean accept) {
        friendService.respondToRequest(from, to, accept);
    }
}