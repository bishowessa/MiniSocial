package service;

import model.FriendRequest;
import java.util.*;

public class FriendService {
    private List<FriendRequest> requests = new ArrayList<>();

    public void sendRequest(String from, String to) {
        requests.add(new FriendRequest(from, to, "pending"));
    }

    public void respondToRequest(String from, String to, boolean accepted) {
        for (FriendRequest req : requests) {
            if (req.getSender().equals(from) && req.getReceiver().equals(to)) {
                req.setStatus(accepted ? "accepted" : "rejected");
                break;
            }
        }
    }

    // Other friend handling logic
}