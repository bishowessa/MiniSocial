package service;

import model.Post;
import model.Comment;
import java.util.*;

public class PostService {
    private List<Post> posts = new ArrayList<>();

    public void createPost(Post post) {
        posts.add(post);
    }

    public List<Post> getUserFeed(String user) {
        // Simplified logic
        return posts;
    }

    public void addComment(String postId, Comment comment) {
        for (Post post : posts) {
            if (post.getId().equals(postId)) {
                post.getComments().add(comment);
                break;
            }
        }
    }

    public void likePost(String postId) {
        for (Post post : posts) {
            if (post.getId().equals(postId)) {
                post.setLikes(post.getLikes() + 1);
                break;
            }
        }
    }
}