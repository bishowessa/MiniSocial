package model;

public class Comment {
    private String user;
    private String message;
    private String timestamp;

    // Constructors, getters, setters
}