package model;

public class FriendRequest {
    private String sender;
    private String receiver;
    private String status; // pending, accepted, rejected

    // Constructors, getters, setters
}