package model;

import java.util.List;

public class Post {
    private String id;
    private String author;
    private String content;
    private String imageUrl; // optional
    private List<Comment> comments;
    private int likes;

    // Constructors, getters, setters
}